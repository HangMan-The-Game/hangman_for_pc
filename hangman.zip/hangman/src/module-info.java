/**
 * @author EMANUELE DOLCE
 * **/


module hangman {
	requires java.desktop;
	requires java.logging;
	requires JTattoo;
	requires opencsv;
}